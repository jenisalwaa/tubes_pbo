package lasttubes;

public class Controller {
    private Admin frame1;

    public Controller() {
        frame1 = new Admin();
        frame1.setTitle("Admin");
   }
    
    public void showDefaultView(){
        frame1.setVisible(true);
    }
}
