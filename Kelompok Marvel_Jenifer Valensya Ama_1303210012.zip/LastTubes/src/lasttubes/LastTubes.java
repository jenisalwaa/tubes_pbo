package lasttubes;

public class LastTubes {

    public static void main(String[] args) {
        User u = new User();
        u.setVisible(true);
    }
    
}
